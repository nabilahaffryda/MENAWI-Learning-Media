

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <div class="breadcrumbs">
        <div class="col-sm-4">
            <div class="page-header float-left">
                <div class="page-title">
                    <h1>Dashboard</h1>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content mt-3">
        
        <div class="col-sm-6 col-lg-3">
            <div class="card">
                <div class="card-body">
                    <div class="stat-widget-one">
                        <div class="stat-icon dib"><i class="ti-user text-primary border-primary"></i></div>
                        <div class="stat-content dib">
                            <div class="stat-text">Total User</div>
                            <div class="stat-digit"><?php echo e($user); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-sm-6 col-lg-3">
            <div class="card">
                <div class="card-body">
                    <div class="stat-widget-one">
                        <div class="stat-icon dib"><i class="ti-book text-success border-success"></i></div>
                        <div class="stat-content dib">
                            <div class="stat-text">Total Materi</div>
                            <div class="stat-digit"><?php echo e($material); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-sm-6 col-lg-3">
            <div class="card">
                <div class="card-body">
                    <div class="stat-widget-one">
                        <div class="stat-icon dib"><i class="ti-write text-warning border-warning"></i></div>
                        <div class="stat-content dib">
                            <div class="stat-text">Total Deskripsi</div>
                            <div class="stat-digit"><?php echo e($description); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-sm-6 col-lg-3">
            <div class="card">
                <div class="card-body">
                    <div class="stat-widget-one">
                        <div class="stat-icon dib"><i class="ti-stats-up text-info border-info"></i></div>
                        <div class="stat-content dib">
                            <div class="stat-text">Total Level</div>
                            <div class="stat-digit"><?php echo e($level); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-lg-3">
            <div class="card">
                <div class="card-body">
                    <div class="stat-widget-one">
                        <div class="stat-icon dib"><i class="ti-files text-success border-success"></i></div>
                        <div class="stat-content dib">
                            <div class="stat-text">Total Tema</div>
                            <div class="stat-digit"><?php echo e($theme); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-lg-3">
            <div class="card">
                <div class="card-body">
                    <div class="stat-widget-one">
                        <div class="stat-icon dib"><i class="ti-menu-alt text-primary border-primary"></i></div>
                        <div class="stat-content dib">
                            <div class="stat-text">Total Pertanyaan</div>
                            <div class="stat-digit"><?php echo e($question); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-lg-3">
            <div class="card">
                <div class="card-body">
                    <div class="stat-widget-one">
                        <div class="stat-icon dib"><i class="ti-import text-info border-info"></i></div>
                        <div class="stat-content dib">
                            <div class="stat-text">Total Jawaban</div>
                            <div class="stat-digit"><?php echo e($answer); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MENAWI-Learning-Media\backend\resources\views/dashboard.blade.php ENDPATH**/ ?>