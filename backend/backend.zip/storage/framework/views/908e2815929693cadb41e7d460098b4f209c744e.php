
<?php $__env->startSection('title', 'Deskripsi Edit Data'); ?>
<?php $__env->startSection('breadcrumbs'); ?>
    <div class="breadcrumbs">
        <div class="col-sm-4">
            <div class="page-header float-left">
                <div class="page-title">
                    <h1> Deskripsi Edit Data</h1>
                </div>
            </div>
        </div>
        <div class="col-sm-8">
            <div class="page-header float-right">
                <div class="page-title">
                    <ol class="breadcrumb text-right">
                        <li><a href="/">Dashboard</a></li>
                        <li><a href="javascript:history.back()">Deskripsi</a></li>
                        <li class="active">Edit</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content mt-3">
        <div class="animated fadeIn">
            <div class="row">
                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-header">
                            <strong>Deskripsi</strong> Edit Data
                        </div>
                        <div class="card-body card-block">
                            <form action="<?php echo e(route('description.update', $description->desc_id)); ?>"
                                enctype="multipart/form-data" method="POST">
                                <div class="form-group">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <label for="desc_id" class=" form-control-label">ID Deskripsi</label>
                                    <input type="integer" id="desc_id" name="desc_id" placeholder="ID Deskripsi"
                                        class="form-control" value="<?php echo e($description->desc_id); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="material_id" class=" form-control-label">Materi</label>
                                    <select id="material_id" name="material_id" placeholder="Materi" style="width: 100%"
                                        class="form-control select2">
                                        <option disabled value>Pilih Materi</option>
                                        <option value="<?php echo e($description->material_id); ?>">
                                            <?php echo e($description->material->material_name); ?>

                                            <?php $__currentLoopData = $mtrl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->material_id); ?>"><?php echo e($item->material_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="description" class=" form-control-label">Deskripsi</label>
                                    <input type="text" id="description" name="description" placeholder="Deskripsi"
                                        class="form-control" value="<?php echo e($description->description); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="desc_pict" class=" form-control-label">Gambar Deskripsi</label>
                                    <input type="file" id="desc_pict" name="desc_pict" class="form-control-file"
                                        value="<?php echo e($description->desc_pict); ?>">
                                    <br>
                                    <?php if($description->desc_pict): ?>
                                        <div style="max-height: 100px; max-width:100px; overflow:hidden;">
                                            <img src="<?php echo e(asset('storage/' . $description->desc_pict)); ?>"
                                                alt="<?php echo e($description->desc_pict); ?>" class="img-fluid">
                                        </div>
                                    <?php else: ?>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-success btn-sm pull-right">
                                        Simpan
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MENAWI-Learning-Media\backend\resources\views/description/edit.blade.php ENDPATH**/ ?>